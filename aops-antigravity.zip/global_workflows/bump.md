---
name: bump
category: instruction
description: Used to nudge an agent back into action
allowed-tools: []
permalink: commands/bump
---

*bump*. You seem to be stuck -- please continue.
